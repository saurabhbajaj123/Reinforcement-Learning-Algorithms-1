How to:

install the following depndencies
collections
statistics
numpy
random
matplotlib

To Run
python3 <filename>